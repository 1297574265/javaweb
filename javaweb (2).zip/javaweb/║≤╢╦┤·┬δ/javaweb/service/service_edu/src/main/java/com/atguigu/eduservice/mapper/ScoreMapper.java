package com.atguigu.eduservice.mapper;

import com.atguigu.eduservice.entity.Score;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-05-23
 */
public interface ScoreMapper extends BaseMapper<Score> {

}
