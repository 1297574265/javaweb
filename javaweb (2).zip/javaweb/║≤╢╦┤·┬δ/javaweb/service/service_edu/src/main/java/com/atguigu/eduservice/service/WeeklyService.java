package com.atguigu.eduservice.service;

import com.atguigu.eduservice.entity.Weekly;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author testjava
 * @since 2021-05-16
 */
public interface WeeklyService extends IService<Weekly> {

}
