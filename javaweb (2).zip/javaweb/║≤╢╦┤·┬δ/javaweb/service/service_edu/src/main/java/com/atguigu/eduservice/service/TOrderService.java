package com.atguigu.eduservice.service;

import com.atguigu.eduservice.entity.TOrder;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 订单 服务类
 * </p>
 *
 * @author testjava
 * @since 2021-05-17
 */
public interface TOrderService extends IService<TOrder> {

    List<TOrder> selectall();
}
