package com.atguigu.eduservice.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 订单
 * </p>
 *
 * @author testjava
 * @since 2021-05-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="TOrder对象", description="订单")
public class TOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id")
    private String serverName;

    @ApiModelProperty(value = "订单数量")
    private long orderNum;

    @ApiModelProperty(value = "服务商数量")
    private long serverNum;

    @ApiModelProperty(value = "服务商id")
    private int userId;


}
