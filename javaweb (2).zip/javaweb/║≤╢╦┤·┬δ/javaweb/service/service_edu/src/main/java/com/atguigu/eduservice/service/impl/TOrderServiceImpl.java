package com.atguigu.eduservice.service.impl;

import com.atguigu.eduservice.entity.TOrder;
import com.atguigu.eduservice.mapper.TOrderMapper;
import com.atguigu.eduservice.service.TOrderService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 订单 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2021-05-17
 */
@Service
public class TOrderServiceImpl extends ServiceImpl<TOrderMapper, TOrder> implements TOrderService {
    @Autowired
    private TOrderMapper tOrderMapper;

    @Override
    public List<TOrder> selectall() {

        List<TOrder> tOrders = tOrderMapper.selectNum();
        return tOrders;
    }
}
