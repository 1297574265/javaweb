package com.atguigu.eduservice.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class OrderQuery {

    @ApiModelProperty(value = "教师名称,模糊查询")
    private String buyer;

}
