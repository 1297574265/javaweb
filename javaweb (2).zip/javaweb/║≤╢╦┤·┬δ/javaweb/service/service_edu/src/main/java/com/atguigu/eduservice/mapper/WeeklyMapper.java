package com.atguigu.eduservice.mapper;

import com.atguigu.eduservice.entity.Weekly;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-05-16
 */
public interface WeeklyMapper extends BaseMapper<Weekly> {

}
