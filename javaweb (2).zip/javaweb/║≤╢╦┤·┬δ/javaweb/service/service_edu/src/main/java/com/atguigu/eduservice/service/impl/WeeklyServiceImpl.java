package com.atguigu.eduservice.service.impl;

import com.atguigu.eduservice.entity.Weekly;
import com.atguigu.eduservice.mapper.WeeklyMapper;
import com.atguigu.eduservice.service.WeeklyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author testjava
 * @since 2021-05-16
 */
@Service
public class WeeklyServiceImpl extends ServiceImpl<WeeklyMapper, Weekly> implements WeeklyService {

}
