package com.atguigu.eduservice.mapper;

import com.atguigu.eduservice.entity.TOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 订单 Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-05-17
 */
public interface TOrderMapper extends BaseMapper<TOrder> {
    @Select("SELECT s.server_num,s.server_name,w.userId,\n" +
            "COUNT( w.id ) AS order_num\n" +
            "FROM weekly AS w\n" +
            "JOIN (SELECT\n" +
            "TG.FID AS server_id,\n" +
            "TG.FN AS server_name,\n" +
            "COUNT( TG.KID ) AS server_num\n" +
            "FROM (\n" +
            "SELECT\n" +
            "A.name AS FN,\n" +
            "A.S_ID AS FID,\n" +
            "B.S_ID AS KID\n" +
            "FROM\n" +
            "USER AS A\n" +
            "INNER JOIN USER AS B ON A.S_ID = B.P_ID\n" +
            ") AS TG\n" +
            "GROUP BY\n" +
            "TG.FID) AS s \n" +
            "ON s.server_id=w.userId\n" +
            "GROUP BY\n" +
            "w.userId\n")
    List<TOrder> selectNum();
}
