package com.atguigu.eduservice.service.impl;

import com.atguigu.eduservice.entity.Score;
import com.atguigu.eduservice.mapper.ScoreMapper;
import com.atguigu.eduservice.service.ScoreService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author testjava
 * @since 2021-05-23
 */
@Service
public class ScoreServiceImpl extends ServiceImpl<ScoreMapper, Score> implements ScoreService {

}
