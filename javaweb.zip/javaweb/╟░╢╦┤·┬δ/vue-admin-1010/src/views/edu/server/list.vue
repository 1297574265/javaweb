<template>
  <div class="app-container">
    讲师列表

    <!--查询表单-->
   
    <!-- 表格 -->
    <el-table
      :data="list"
      border
      fit
      highlight-current-row>

      

      <el-table-column prop="userId" label="服务商id" width="380" />


      <el-table-column prop="serverName" label="服务商名称" width="300"/>

      <el-table-column prop="orderNum" label="订单数量" width="200"/>

      <el-table-column prop="serverNum" label="客服数量" width="200" />

    </el-table>



  </div>
</template>
<script>
//引入调用teacher.js文件
import teacher from '@/api/edu/server'

export default {
    //写核心代码位置
    // data:{
    // },
    data() { //定义变量和初始值
        return {
          list:null,//查询之后接口返回集合
   
          limit:10,//每页记录数
          total:0,//总记录数
          teacherQuery:{} //条件封装对象
        }
    },
    created() { //页面渲染之前执行，一般调用methods定义的方法
        //调用
        this.getList() 
    },
    methods:{  //创建具体的方法，调用teacher.js定义的方法
        //讲师列表的方法
        getList() {
            teacher.getTeacherInfo()
                .then(response =>{//请求成功
                    //response接口返回的数据
                    //console.log(response)
                    this.list = response.data.rows
 
                    console.log(this.total)
                }) 
        },


 
    }
}
</script>
