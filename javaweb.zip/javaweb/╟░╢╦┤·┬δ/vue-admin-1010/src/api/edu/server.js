import request from '@/utils/request'
export default {
    getTeacherInfo() {
        return request({
            url: `/eduservice/t-order/findAll`,
            method: 'get'
          })
    },


}
